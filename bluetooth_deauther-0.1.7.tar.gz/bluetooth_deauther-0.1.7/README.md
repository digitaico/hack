# Bluetooth Deauthor

This package uses your local machine `bluetooth` tools to scan and find Bluetooth Speakers and deauthorize or break the 
communication with any device that is feeding music to it.  It uses a flood attack.

## Installation

This is a python package, can be installed with `pip`.



```bash
pip install bluetooth_deauther-0.1.5.tar.gz
```
It was created by @digitaico.
