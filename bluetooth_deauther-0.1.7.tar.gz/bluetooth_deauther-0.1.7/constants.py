PHONE_BRANDS =['apple', 'iphone', 'samsung', 'oppo', 'huawei', 'xiaomi', 'moto', 'motorola', 'google', 'pixel', 'oneplus', 'sony', 'lg', 'alcatel', 'nokia', 'vivo', 'htc', 'honor', 'blu', 'lenovo', 'acer', 'realme', 'asus', 'amazon', 'amoi', 'cat', 'blackberry', 'orange', 'prestigio', 'razer', 'sagem', 'siemens', 'ericsson', 'sony ericsson', 't-mobile', 'vertu', 'zte']

SPEAKER_BRANDS = ['kalley', 'bose', 'jbl', 'lg', 'samsung', 'xiaomi', 'sony', 'tribit', 'ortizan', 'speaker', 'wireless audio', 'bluetooth speaker', 'ultimate ears', 'anker', 'marshall', 'soundcore', 'phillips', 'amazon echo', 'google home']

SPEAKER_KEYWORDS = ['speaker', 'parlante', 'sound', 'portable', 'wireless', 'soundbar', 'boombox', 'bocina', 'pico', 'equipo', 'sonido', 'barra']
